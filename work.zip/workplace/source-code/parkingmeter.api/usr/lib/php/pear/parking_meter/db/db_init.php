<?php
require_once("activerecord/ActiveRecord.php");
require_once('/data/conf/parking_meter/db/MySQLServerConfig.inc.php');

$connections = MySQLServerConfig::$mdcParkingMeterDatabaseConnections;

# 初始化 ActiveRecord
ActiveRecord\Config::initialize(function ($cfg) use ($connections) {
    $cfg->set_model_directory('.');
    $cfg->set_connections($connections[MySQLServerConfig::DATABASE_DEFAULT_ENV]);
});

