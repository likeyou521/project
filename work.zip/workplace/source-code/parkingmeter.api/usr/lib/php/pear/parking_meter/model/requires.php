<?php

require_once dirname(__FILE__)."/../db/db_init.php";

