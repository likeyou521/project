# 目录说明
1. ParkingMeter的项目API入口
2. 目录结构

~~~js
├── account         //用户
├── calendar        //日历
├── common          //公共
├── parkingcharge   //停车收费
├── parkingrate     //费率
├── parkplace       //泊位
└── prepaidcard     //预付费卡

~~~
