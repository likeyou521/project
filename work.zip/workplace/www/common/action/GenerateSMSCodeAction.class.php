<?php
/**
 *@description : 创建一条新的短信验证码,并发送到提供的手机号码
 *@author      : stephen.mo
 *@date        : Jun 08, 2017
 *@copyright   : Copyright 2017 M.D.C Inc,. Ltd;
 */
require_once('pworks/mvc/action/BaseAction.class.php');


class GenerateSMSCodeAction extends BaseAction {


    public function execute() {


        return 'succ';

    }

}
