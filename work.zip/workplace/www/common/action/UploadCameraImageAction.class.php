<?php
/**
 *@description : 上传一张拍摄的照片到指定服务器位置
 *@author      : stephen.mo
 *@date        : Jun 08, 2017
 *@copyright   : Copyright 2017 M.D.C Inc,. Ltd;
 */
require_once('pworks/mvc/action/BaseAction.class.php');


class UploadCameraImageAction extends BaseAction {


    public function execute() {


        return 'succ';

    }

}
