<?php
/**
 *@description : The start entry for api framework.
 *@author      : stephen.mo <stephen@iot-sw.net>
 *@date        : Mar 18, 2017
 *@version     : 1.0.0
 */

date_default_timezone_set('Asia/Shanghai');

# 定义API中的token
define('WS_TOKEN','mdcwetogether2017');

# 定义项目起始位置
define('APP_ROOT',dirname(__FILE__));

# 处理默认的lib目录
set_include_path(get_include_path().PATH_SEPARATOR.'/usr/lib/php/pear'.PATH_SEPARATOR.APP_ROOT);

/** add by stephen to do put method postfields **/
if (isset($_REQUEST['method']) && (in_array($_REQUEST['method'],['PUT','DELETE']))) {

    $arguments = file_get_contents('php://input');

    if (!empty($arguments)) {

        $arguments    = urldecode($arguments);
        $parse_result = parse_str($arguments,$receiveArgs);

        if (!empty($receiveArgs)) {
            foreach ($receiveArgs as $key=>$val) {
                $_REQUEST[$key] = $val;
            }
        }
    }
}

# 使用本地的项目配置
define('PWORKS_CONFIG_FILE_PATH',APP_ROOT.'/pworks.inc.php');

# 引入框架入口并开始
require_once('pworks/pworks.php');
