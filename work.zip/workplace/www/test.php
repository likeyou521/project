<?php


phpinfo();
